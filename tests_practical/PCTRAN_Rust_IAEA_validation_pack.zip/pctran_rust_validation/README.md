# PCTRAN -> Rust: benchmark na podstawie IAEA TCS-68

**Źródło:** IAEA (2019), *PCTRAN Generic Pressurized Water Reactor Simulator Exercise Handbook*, Training Course Series 68: https://www-pub.iaea.org/MTCD/Publications/PDF/TCS-68web.pdf

**Dotyczy:** PCTRAN **6.0.4**, uproszczony PWR **2 pętle / 1800 MWt / 600 MWe**. Inne wydania lub parametry modelu mogą dawać inne wyniki.

## Instrukcja dla Codexa

Zaimplementuj i uruchom zestaw testów S00–S05 z `scenarios.json`. NIE podmieniaj modeli fizycznych na sztuczne, interpolowane przebiegi pasujące do handbooka. Każdy test wymaga realnego obliczenia stanów w silniku Rusta. Zapisuj snapshot parametrów co 1 s czasu symulacji, dodatkowo loguj zdarzenia RPS, RCP, FWIV, AFW i bypass z dokładnym czasem symulowanym.

**Krok 1: mapowanie.** Sprawdź, czy import IC#1 i IC#4 jest zgodny z Appendix A.3. Zachowaj jednostki, rozróżniaj SG-A / SG-B, wskaźnik poziomu SG narrow range (%) i wide range (m), moc neutronową / cieplną / obciążenie turbiny oraz „trip command” / „trip state”. Zbierz CSV `time_s` z wartościami zgodnymi ze zdefiniowanymi nazwami pól (patrz niżej).

**Krok 2: uruchom S00, S01, S02, S03, S04, S05.** Przygotuj osobny CSV na scenariusz. `time_s=0` to chwila **wznowienia** po załadowaniu IC, ok. 5 s wygrzewania, pauzie i wprowadzeniu sterowania / zakłócenia. Nie myl z czasem od startu aplikacji.

**Krok 3: automatyczne porównanie.** Uruchom `compare.py`. Endpointy sprawdzane przy ~1000 s, czasy zadziałania osobno. Dla każdego sygnału porównuj kształt przebiegu, czas minimum/maksimum, zgodność kolejności zdarzeń i ewentualne oscylacje. Oceniaj też błąd bilansu masy/energii i deterministyczność integratora (te ostatnie testy są własnymi rozszerzeniami, nie benchmarkiem MAEA).

**Krok 4: porównanie wykresów.** `compare.py` tworzy własne obrazy `RUST_fig_XX.png`. Jeżeli podasz lokalny oryginał PDF przez `--handbook`, program wytnie odpowiednie fragmenty wykresów jako `IAEA_fig_XX.png`, a następnie złoży pary `COMPARE_fig_XX.png` (MAEA po lewej / Rust po prawej). **Nie ma tutaj „złotych”, dokładnych CSV z wykresów IAEA**: źródłowe rysunki to obrazy. Jeśli potrzebna walidacja punkt po punkcie, najpierw wyeksportuj numeryczne CSV z oryginalnego PC-TRAN lub zdigitalizuj wykres jawnie oznaczając błąd digitalizacji. Nie fikcyjnie generuj brakujących pomiarów.

**Krok 5: raport.** Dla każdego testu napisz: PASS/FAIL/INCOMPLETE; które parametry nie pasują; pierwszy moment rozjazdu; największy błąd względem referencji; możliwe przyczyny (kinetyka, termohydraulika, sterowanie, logika RPS, integrator, jednostki); wykresy; hash commita Rusta.

## Scenariusze i wartości

| Test | IC | Sterowanie | Oczekiwanie MAEA | Literatura |
|---|---|---|---|---|
| S00 | IC#1 | brak zakłóceń, 1000 s | stabilność (własny smoke test, nie rozdział handbooka) | Appendix A.3 |
| S01 | IC#1 | turbina 75%, rampa 5%/min, 1000s | 1351 MWt, 450 MWe, Tavg 296.8C, RCS 155 bar, PZR 48.3%, SG-A 57 bar, SG 50%, pręty 90% | 2.1 / tabela 3 / fig. 6–10 |
| S02 | IC#4 | turbina 100%, rampa 5%/min, 1000s | 1805 MWt, 600 MWe, Tavg 300C, RCS 155 bar, PZR 57%, SG-A 55.7 bar, SG 50%, pręty 100% | 2.2 / tabela 4 / fig. 13–16 |
| S03 | IC#1 | manual Reactor Trip | trip turbiny; FWIV ~45s gdy Tavg=281C; AFW ~1750s gdy SG NR=17%; decay heat | 2.4 / tabela 6 / fig. 27–30 |
| S04 | IC#1 | RCP-B OFF | spadek mocy ~30% przed SCRAM; SCRAM ~10–15s; backflow pętli B ~40–50s | 3.1 / tabela 7 / fig. 36–39 |
| S05 | IC#1 | trzy główne pompy wody zasilającej OFF | utrata feedwater; moc ~90% przed trip; SCRAM i AFW ~50–60s; SG level wraca | 3.2 / tabela 8 / fig. 43–46 |

> **Istotne:** czasy S04 i S05 w tabelach/tekście MAEA są zaokrąglone i miejscami różnią się o ~10 s. Weryfikuj je jako przedział, nie exact match. Również IC#1 w Appendix A.3 zawiera 70 bar SG, chociaż wykresy późniejszych stanów pokazują ok. 55–57 bar: nie wymuszaj stałości 70 bar po 1000s.

## Format CSV

Zapisz nagłówek (można dodać własne kolumny, brakujące sygnały dadzą INCOMPLETE zamiast fałszywego PASS):

```csv
time_s,rod_position_pct,reactor_power_mwt,generator_power_mwe,tavg_c,rcs_pressure_bar,prz_level_pct,sg_a_pressure_bar,sg_a_level_nr_pct,sg_b_level_nr_pct,turbine_load_pct,reactor_trip,turbine_trip,fwiv_open,afw_running,rcp_a_flow_tph,rcp_b_flow_tph,sg_a_feedwater_tph,sg_a_steam_tph,hot_leg_a_c,cold_leg_a_c
```

`reactor_trip`, `turbine_trip`, `afw_running`, `fwiv_open` mają wartości 0/1. Nazwy sygnałów z Appendix A.5, np. QMWT/TAVG/WRCA/WRCB/PSGA/WFWA/WSTA/NSGA/TBLD, są też częściowo akceptowane jako aliasy przez skrypt.

## Polecenia

```bash
python3 -m pip install matplotlib pymupdf pillow
python3 compare.py --case S01 --csv traces/S01.csv --handbook ~/Downloads/TCS-68web.pdf --out reports/S01
python3 compare.py --case S04 --csv traces/S04.csv --handbook ~/Downloads/TCS-68web.pdf --out reports/S04
```

PDF należy pobrać z linku MAEA powyżej; **oryginał nie jest częścią tego pakietu**. Skrypt nie wymaga PDF do testów liczbowych i tworzenia wykresów Rusta.

### Poza handbookiem: bardzo ważne testy inżynieryjne

1. Zmiana długości kroku integratora (dt, dt/2) i zgodność trendów / czasów przejść.
2. Determinizm: identyczna sekwencja interwencji i IC daje identyczny wynik (w granicach tolerancji FP).
3. Bilans masy/energii dla RCS, SG i CVCS, z uwzględnieniem charging/letdown, przecieków i przejść fazowych.
4. Save/load symulacji po 300 s i kontynuacja: zgodność z ciągłą symulacją, a także jawne ujawnienie brakujących stanów wewnętrznych.
5. Jednostki SI, ciśnienia bezwzględne / względne, konwersje °C↔K i %↔ułamki.

Brak modeli/kolumn lub nieosiągalny czas 1750s raportuj jako `INCOMPLETE`, a nie `PASS`.
