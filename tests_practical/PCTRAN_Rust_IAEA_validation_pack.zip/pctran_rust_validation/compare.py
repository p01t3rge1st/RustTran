#!/usr/bin/env python3
"""PCTRAN Rust vs IAEA TCS-68: checkpoints and side-by-side plot generator.

Actual reference curves are NOT digitized or invented. If a locally obtained
IAEA PDF is supplied, its figures are cropped and juxtaposed with Rust traces.
"""
import argparse, csv, json, math, re
from pathlib import Path

HERE=Path(__file__).resolve().parent
SPEC=json.loads((HERE/'scenarios.json').read_text(encoding='utf-8'))
FIG=json.loads((HERE/'figures.json').read_text(encoding='utf-8'))

# All tolerances here are deliberately provisional: adjust after confirming
# real PCTRAN 6.0.4 reference output. They are NOT from the IAEA handbook.
TOL={
 'rod_position_pct':3, 'reactor_power_mwt':35, 'tavg_c':2.0,
 'rcs_pressure_bar':1.5, 'prz_level_pct':3.0,
 'generator_power_mwe':8, 'sg_a_pressure_bar':2,
 'sg_a_level_nr_pct':3
}
PLOT_INDEX={str(f['figure']): f for f in FIG['figures']}

def load_trace(path):
    with open(path,newline='',encoding='utf-8-sig') as fp:
        r=csv.DictReader(fp)
        data=list(r)
        names=r.fieldnames or []
    if 'time_s' not in names:
        raise ValueError("CSV must have 'time_s' (seconds from resumed intervention). Found: " + ', '.join(names))
    canon=SPEC['handbook_plottable_codes']
    # Accept PCTRAN handbook raw variable names as alternatives to canonical names
    for row in data:
        for raw,standard in canon.items():
            if standard not in row and raw in row:
                row[standard]=row[raw]
        if 'reactor_power_mwt' in row and 'core_pct' not in row and row['reactor_power_mwt']:
            try: row['core_pct']=float(row['reactor_power_mwt'])/1800*100
            except ValueError: pass
    return data

def num(row,key):
    try:
        val=float(row[key]); return val if math.isfinite(val) else None
    except (ValueError, TypeError, KeyError): return None

def closest(data,t):
    return min(data,key=lambda r:abs(num(r,'time_s')-t))

def first_true(data,key):
    for row in data:
        val=str(row.get(key,'')).strip().lower()
        if val in ('1','true','on','yes','tripped','closed','running','active'):
            return num(row,'time_s')
    return None

def first_negative(data,key):
    for row in data:
        v=num(row,key)
        if v is not None and v<0: return num(row,'time_s')
    return None

def first_false(data,key):
    for row in data:
        val=str(row.get(key,'')).strip().lower()
        if val in ('0','false','off','no','closed'):
            return num(row,'time_s')
    return None

def validate(data,scenario):
    c=[]
    def add(label,result,detail): c.append({'name':label,'status':result,'detail':detail})
    if not data: raise ValueError('Empty CSV')
    ts=[num(row,'time_s') for row in data]
    if any(t is None for t in ts): raise ValueError('Time values must be finite numbers')
    if any(b<=a for a,b in zip(ts,ts[1:])): raise ValueError('time_s must be strictly increasing')
    add('CSV time monotonic','PASS',f'{len(ts)} samples, {ts[0]:g}..{ts[-1]:g} s')
    endpoints=scenario.get('endpoint_at_1000_s',{})
    if endpoints:
        point=closest(data,1000)
        t=num(point,'time_s')
        if abs(t-1000)>5:
            add('Endpoint sample at ~1000 s','INCOMPLETE',f'Nearest sample: t={t:g}s (require within +/-5s)')
        else:
            for key,expected in endpoints.items():
                value=num(point,key)
                if value is None:
                    add(f't=1000 {key}','INCOMPLETE',f'Column {key} not present')
                    continue
                tol=TOL[key]
                ok=abs(value-expected)<=tol
                add(f't=1000 {key}', 'PASS' if ok else 'FAIL',f'actual={value:.4g}; IAEA≈{expected:g}; provisional tolerance +/-{tol:g}')
    # Event timings are approximate; wide intervals reflect handbook narrative ambiguities.
    events={'S03':[('FWIV close','fwiv_open','false',45,15),('AFW start','afw_running','true',1750,200)],
            'S04':[('Reactor trip','reactor_trip','true',15,10),('Reverse RCP-B flow','rcp_b_flow_tph','negative',40,25)],
            'S05':[('Reactor trip','reactor_trip','true',50,20),('AFW start','afw_running','true',50,25)]}
    for label,key,how,ref,delta in events.get(scenario['id'],[]):
        if key not in data[0]:
            add(label,'INCOMPLETE',f'No event/measurement column: {key}')
            continue
        detected={'true':first_true,'false':first_false,'negative':first_negative}[how](data,key)
        if detected is None:
            if ts[-1]<ref-delta:
                add(label,'INCOMPLETE',f'Trace ends at {ts[-1]:g}s, before the expected time window')
            else: add(label,'FAIL',f'Event not found within trace (expected near {ref}s)')
            continue
        ok=abs(detected-ref)<=delta
        add(label,'PASS' if ok else 'FAIL',f'detected={detected:g}s; handbook≈{ref}s; provisional window +/-{delta}s')
    if scenario['id']=='S00':
        if 'reactor_trip' in data[0]:
            add('No spontaneous reactor trip','PASS' if first_true(data,'reactor_trip') is None else 'FAIL','Trip must not happen without operator disturbance')
        else: add('No spontaneous reactor trip','INCOMPLETE','reactor_trip signal absent')
        for key,tol in [('reactor_power_mwt',40),('rcs_pressure_bar',2),('tavg_c',3)]:
            if ts[-1]<1000 or key not in data[0]:
                add(f'No steady-state drift: {key}','INCOMPLETE','Trace too short or key absent');continue
            a=num(closest(data,500),key); b=num(closest(data,1000),key)
            if a is None or b is None: add(f'No steady-state drift: {key}','INCOMPLETE','Missing numbers');continue
            add(f'No steady-state drift: {key}','PASS' if abs(b-a)<=tol else 'FAIL',f'|1000s - 500s|={abs(b-a):.4g} (provisional limit {tol:g})')
    return c

def extract_figure(pdf,number,outdir):
    import fitz
    meta=PLOT_INDEX[str(number)]
    page=pdf[meta['page_index']]
    # Figure caption search; use pdf-side numbering index, not printed page.
    spots=page.search_for(f'FIG. {number}.') or page.search_for(f'FIG. {number}')
    if not spots:
        text=page.get_text()
        raise RuntimeError(f"Caption FIG. {number}. not found on PDF index {meta['page_index']}; manually inspect it. Snippet: {text[-300:]}")
    caption=spots[-1]
    rect=page.rect
    left=max(0, rect.width*0.14)
    right=min(rect.width,rect.width*0.86)
    top=max(0,caption.y0-310)
    bottom=min(rect.height,caption.y1+15)
    clip=fitz.Rect(left,top,right,bottom)
    pix=page.get_pixmap(matrix=fitz.Matrix(2,2),clip=clip,alpha=False)
    out=outdir / f'IAEA_fig_{number:02d}.png'
    pix.save(out)
    return out

def side_by_side(original, computed, output, fig_number):
    from PIL import Image, ImageOps, ImageDraw
    with Image.open(original) as a, Image.open(computed) as b:
        h=650
        def fit(im):
            cp=im.convert('RGB')
            cp.thumbnail((820,h-45))
            panel=Image.new('RGB',(840,h),'white')
            panel.paste(cp,((840-cp.width)//2,38))
            return panel
        left,right=fit(a),fit(b)
        sheet=Image.new('RGB',(1680,h),'white')
        sheet.paste(left,(0,0));sheet.paste(right,(840,0))
        draw=ImageDraw.Draw(sheet)
        draw.text((20,12),f'IAEA handbook (Fig. {fig_number})',fill='black')
        draw.text((860,12),f'Rust simulation (analogue Fig. {fig_number})',fill='black')
        draw.line((840,0,840,h),fill='#bbbbbb',width=2)
        sheet.save(output)

def chart(data,meta,out):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,ax=plt.subplots(figsize=(8.3,5.0))
    times=[num(row,'time_s') for row in data]
    plotted=0
    for key in meta['columns']:
        if key not in data[0]: continue
        vals=[num(row,key) for row in data]
        if all(y is None for y in vals): continue
        ax.plot(times,vals,label=key,linewidth=1.5);plotted+=1
    ax.set_title(f'RUST: Figure {meta["figure"]} analogue — {meta["title"]}')
    ax.set_xlabel('t [s] relative to disturbance')
    ax.set_xlim(0,meta['range_s'])
    ax.grid(True, alpha=.3)
    if plotted: ax.legend(fontsize=8)
    else: ax.text(.5,.5,'MISSING SIGNALS / MAPPING',transform=ax.transAxes,ha='center')
    fig.tight_layout();fig.savefig(out,dpi=140);plt.close(fig)

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--case',required=True,choices=[s['id'] for s in SPEC['scenarios']])
    p.add_argument('--csv',required=True,type=Path,help='Trace exported by Rust simulation')
    p.add_argument('--handbook',type=Path,help='IAEA handbook PDF already downloaded locally')
    p.add_argument('--out',type=Path,default=Path('validation_report'))
    args=p.parse_args()
    args.out.mkdir(parents=True,exist_ok=True)
    scenario=next(s for s in SPEC['scenarios'] if s['id']==args.case)
    data=load_trace(args.csv)
    checks=validate(data,scenario)
    for c in checks: print(f'[{c["status"]:10}] {c["name"]}: {c["detail"]}')
    from collections import Counter
    counts=dict(Counter(c['status'] for c in checks))
    status='FAIL' if counts.get('FAIL') else ('INCOMPLETE' if counts.get('INCOMPLETE') else 'PASS')
    print('OVERALL:', status, counts)
    (args.out/'checks.json').write_text(json.dumps({'scenario':args.case,'status':status,'checks':checks},indent=2,ensure_ascii=False),encoding='utf-8')
    if scenario.get('figures'):
        try:
            import matplotlib
        except ImportError as e: raise SystemExit('Plotting needs matplotlib (pip install matplotlib)') from e
        pdf=None
        if args.handbook:
            import fitz
            pdf=fitz.open(args.handbook)
        for number in scenario['figures']:
            meta=PLOT_INDEX[str(number)]
            chart(data,meta,args.out/f'RUST_fig_{number:02d}.png')
            if pdf:
                try:
                    original=extract_figure(pdf,number,args.out)
                    side_by_side(original,args.out/f'RUST_fig_{number:02d}.png',args.out/f'COMPARE_fig_{number:02d}.png',number)
                except Exception as e: print(f'WARN: could not extract Figure {number}: {e}')
        if pdf: pdf.close()
    print('Report directory:', args.out.resolve())
    print('NOTE: COMPARE_fig_*.png pairs original IAEA figure with Rust curve; the original is an illustration, not machine-readable truth.')

if __name__=='__main__': main()
